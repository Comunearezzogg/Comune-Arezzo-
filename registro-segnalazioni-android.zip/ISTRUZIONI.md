# Registro Segnalazioni — Installazione su Android e aggiornamenti

L'app è una **PWA (Progressive Web App)**: si installa dal browser e appare sul telefono con la sua icona, a schermo intero, come una normale app Android. Funziona anche offline. Serve solo pubblicarla su un indirizzo web gratuito (operazione di 10 minuti, una volta sola).

## Contenuto del pacchetto

| File | A cosa serve |
|---|---|
| `index.html` | L'app vera e propria |
| `manifest.json` | Nome, icona e colori per l'installazione |
| `sw.js` | Service worker: offline + meccanismo di aggiornamento |
| `icon-192.png`, `icon-512.png` | Icone dell'app |

## 1. Pubblicazione su GitHub Pages (gratuito, una volta sola)

1. Crea un account gratuito su **github.com** (se non lo hai già).
2. In alto a destra: **+ → New repository**. Nome: `registro-segnalazioni`. Spunta **Public**. Premi **Create repository**.
3. Nella pagina del repository: **uploading an existing file** (oppure Add file → Upload files). Trascina **tutti e 5 i file** di questo pacchetto. Premi **Commit changes**.
4. Vai su **Settings → Pages** (menu a sinistra). Sotto "Branch" seleziona **main** e cartella **/ (root)**, poi **Save**.
5. Dopo 1–2 minuti l'app sarà online all'indirizzo:
   `https://TUONOME.github.io/registro-segnalazioni/`

## 2. Installazione sul telefono Android

1. Apri l'indirizzo qui sopra con **Chrome** sul telefono.
2. Chrome mostrerà "**Aggiungi Registro Segnalazioni alla schermata Home**" (oppure: menu ⋮ → **Installa app** / **Aggiungi a schermata Home**).
3. Conferma. L'icona compare tra le app: da lì in poi si apre a schermo intero come un'app nativa.

Puoi installarla su più dispositivi (telefono, tablet): ognuno ha i **propri dati locali**. Per spostare i dati usa Esporta/Importa backup (vedi sotto).

## 3. Come fare gli aggiornamenti

Quando vorrai modifiche (nuovi campi, esportazione Excel, scadenze, ecc.):

1. Chiedimi la modifica: ti consegnerò una nuova `index.html` (ed eventualmente un nuovo `sw.js`).
2. Su GitHub apri il repository → clicca su `index.html` → icona **matita** (Edit) → incolla il nuovo contenuto → **Commit changes**. Stessa cosa per `sw.js`.
3. **Importante**: in `sw.js` la riga `const CACHE = 'rs-v1';` deve cambiare numero a ogni aggiornamento (`rs-v2`, `rs-v3`, …). Se ti consegno io il file, il numero sarà già aggiornato.
4. Sul telefono: chiudi e riapri l'app con la rete attiva. La nuova versione si scarica da sola.

**I dati non si perdono con gli aggiornamenti** (sono salvati sul telefono, non nel file dell'app). Per prudenza, prima di ogni aggiornamento fai comunque **Argomenti → Esporta backup**.

## 4. Backup dei dati

- **Argomenti → Esporta backup**: scarica un file `.json` con tutte le note. Conservalo (es. su Drive).
- **Argomenti → Importa backup**: ripristina i dati da un file esportato (utile per cambio telefono o dopo una cancellazione dei dati di Chrome).

⚠️ I dati vivono nella memoria di Chrome sul dispositivo: se cancelli i "dati dei siti" di Chrome o disinstalli l'app, si perdono. Il backup periodico è la tua rete di sicurezza.

## Opzionale: vera APK sul Play Store

Se in futuro volessi un file APK vero e proprio (per distribuirlo ai colleghi senza passare dal browser), dal sito **pwabuilder.com** puoi incollare l'indirizzo GitHub Pages e generare automaticamente un pacchetto Android. Non è necessario per l'uso personale: la PWA installata è già indistinguibile da un'app nativa.
